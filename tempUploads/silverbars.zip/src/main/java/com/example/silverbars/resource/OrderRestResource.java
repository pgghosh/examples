/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.example.silverbars.resource;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.silverbars.model.Order;
import com.example.silverbars.model.OrderSummary;

/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */
@Path("/orders")
@Component
public class OrderRestResource {

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/addOrder")
    public String addOrder(@RequestBody final Order order) {
        return "Hello World";
    }

    @DELETE
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/{orderId}")
    public String deleteOrder(@PathParam("orderId") final String orderId) {
        return "Hello World";
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/summary")
    public OrderSummary getOrderSummary() {
        return new OrderSummary();
    }
}
