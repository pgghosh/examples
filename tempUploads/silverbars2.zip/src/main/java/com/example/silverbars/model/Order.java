package com.example.silverbars.model;

/**
 * <p>
 * <b> DTO bean to hold Order details. </b>
 * </p>
 */
public class Order {

    private String id;
    private String userId;
    private double quantity; // in kgs
    private double unitPrice; // per kg

    /**
     * @return the id
     */
    public String getId() {
        return this.id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(final String id) {
        this.id = id;
    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return this.userId;
    }

    /**
     * @param userId
     *            the userId to set
     */
    public void setUserId(final String userId) {
        this.userId = userId;
    }

    /**
     * @return the quantity
     */
    public double getQuantity() {
        return this.quantity;
    }

    /**
     * @param quantity
     *            the quantity to set
     */
    public void setQuantity(final double quantity) {
        this.quantity = quantity;
    }

    /**
     * @return the unitPrice
     */
    public double getUnitPrice() {
        return this.unitPrice;
    }

    /**
     * @param unitPrice
     *            the unitPrice to set
     */
    public void setUnitPrice(final double unitPrice) {
        this.unitPrice = unitPrice;
    }


}
