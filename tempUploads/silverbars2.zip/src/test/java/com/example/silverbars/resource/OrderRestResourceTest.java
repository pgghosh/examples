/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.example.silverbars.resource;

import static com.jayway.restassured.RestAssured.when;
import static org.junit.Assert.fail;

import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.example.silverbars.model.Order;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class OrderRestResourceTest {

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {}

    @AfterClass
    public static void tearDownAfterClass() throws Exception {}

    @Before
    public void setUp() throws Exception {}

    @After
    public void tearDown() throws Exception {}

    @Test
    public void testAddOrder() {
        Order order = new Order();
        order.setUserId("12345");
        when().post("/orders/addOrder", order).then().statusCode(HttpStatus.SC_OK).body("id", Matchers.notNullValue())
            .body("userId", Matchers.is(order.getUserId()));
    }

    @Test
    public void testCancelOrder() {

        when().delete("/orders/111")

            .then().statusCode(HttpStatus.SC_OK).body("id", Matchers.notNullValue()).body("userId", Matchers.is(order.getUserId()));
    }

    @Test
    public void testGetOrderSummary() {
        fail("Not yet implemented");
    }

}
